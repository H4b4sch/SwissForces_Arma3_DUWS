support_supplydrop_available = false;
support_paradrop_available = false;
support_jdam_available = false;
support_mortar_available = false;
support_arty_available = false;
support_pFLIR_available = false;
support_uav_recon_available = false;
support_veh_refit_available = false;
support_helotaxi_available = false;
support_boattaxi_available = false;
support_cluster_available = false;



	if (isNil "support_specialized_training_available") then
	{
	support_specialized_training_available = false;
	};

	if (isNil "support_armory_available") then
	{
	support_armory_available = false;
	};
	
	if (isNil "support_halo_available") then
	{
	support_halo_available = false;
	};