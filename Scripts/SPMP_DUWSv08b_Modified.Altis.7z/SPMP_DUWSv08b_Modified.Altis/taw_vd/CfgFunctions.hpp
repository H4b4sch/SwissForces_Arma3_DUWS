class TAWVD
{
	tag = "TAWVD";
	class TAW_VD
	{
		file = "taw_vd";
		class onSliderChange {};
		class onTerrainChange {};
		class updateViewDistance {};
		class openTAWVD {};
		class trackViewDistance {};
		class tawvdInit {postInit = 1;};
	};
};