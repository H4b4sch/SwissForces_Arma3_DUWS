class CfgDebriefing
{  
	class island_captured_win
	{
		title = "Island Captured!";
		subtitle = "";
		description = "You have successfully captured all the zones and destroyed the enemy forces on the island. This island is now under BLUFOR control. Time to take back another island, soldier...";
		pictureBackground = "";
		picture = "\a3\ui_f\data\gui\cfg\hints\UnitType_ca.paa";
		pictureColor[] = {0.0,0,1,1};
	};
 	class officerkilled
	{
		title = "HQ Officer Killed";
		subtitle = "";
		description = "Your commanding officer has been killed, you are now alone and stranded on the island. You will be evacuated shortly.";
		pictureBackground = "";
		picture = "\a3\ui_f\data\gui\cfg\hints\ActionMenu_ca.paa";
		pictureColor[] = {1,0,0,1};
	};
};
