class CfgHints
{
  class Mainclass
  {
  displayName = "Main class";
	 class wtf
	 {
      arguments[] = {[["MoveForward"]],[["SwimUp"]],[["SwimDown"]],[["MoveForward"]],[["MoveBack"]],[["TurnLeft"]],[["TurnRight"]]};
      description = "%1%2Aim down and move forward %11 to dive.%1%2Ascend with %12.%1%2Descend with %13.%1%2Move with %14, %15, %16, %17.";
      displayName = "DERPING";
      image = "\a3\ui_f\data\gui\cfg\hints\BasicDive_ca.paa";
      tip = "Equip a re-breather to a vest slot to supply oxygen for longer dives. For clear underwater vision, equip diving goggles to the goggles slot."; 
	 };
	};
};